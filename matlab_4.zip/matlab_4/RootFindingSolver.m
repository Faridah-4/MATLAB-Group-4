classdef (Abstract) RootFindingSolver < NumericalSolver
    % ROOTFINDINGSOLVER Abstract class for root finding methods
    % Inherits from NumericalSolver and adds root-specific functionality
    
    properties (Constant)
        SOLVER_TYPE = 'Root Finding'
    end
    
    properties
        root
        initialGuess
        functionValue
        derivativeFunction
    end
    
    methods
        function obj = RootFindingSolver(name, f, df, x0, tolerance, maxIterations)
            % Call parent constructor
            obj = obj@NumericalSolver(name, tolerance, maxIterations);
            
            if nargin > 0
                obj.problemFunction = f;
                obj.derivativeFunction = df;
                obj.initialGuess = x0;
            end
        end
        
        function validateParameters(obj)
            % Validate root finding parameters
            if isempty(obj.problemFunction)
                error('Problem function must be specified');
            end
            
            if obj.tolerance <= 0
                error('Tolerance must be positive');
            end
            
            if obj.maxIterations <= 0
                error('Maximum iterations must be positive');
            end
            
            fprintf('%s parameters validated\n', obj.name);
        end
        
        function displayResults(obj)
            % Display root finding results
            fprintf('\n=== %s RESULTS ===\n', upper(obj.name));
            fprintf('Method: %s\n', obj.name);
            fprintf('Root: %.8f\n', obj.root);
            fprintf('f(root): %.2e\n', obj.functionValue);
            fprintf('Iterations: %d\n', obj.iterations);
            fprintf('Computation Time: %.6f seconds\n', obj.computationTime);
            fprintf('Converged: %s\n', string(obj.hasConverged));
            
            if obj.hasConverged
                fprintf('Solution converged within tolerance\n');
            else
                fprintf('Solution did not converge within maximum iterations\n');
            end
        end
    end
end