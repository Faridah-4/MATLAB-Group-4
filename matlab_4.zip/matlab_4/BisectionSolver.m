classdef BisectionSolver < RootFindingSolver
    % BISECTIONSOLVER Concrete implementation of Bisection method
    
    properties
        lowerBound
        upperBound
    end
    
    methods
        function obj = BisectionSolver(f, a, b, tolerance, maxIterations)
            obj = obj@RootFindingSolver('Bisection', f, [], (a+b)/2, tolerance, maxIterations);
            obj.lowerBound = a;
            obj.upperBound = b;
        end
        
        function result = solve(obj)
            % Implement Bisection method recursively
            tic;
            obj.validateParameters();
            
            if obj.problemFunction(obj.lowerBound) * obj.problemFunction(obj.upperBound) > 0
                error('Function must have opposite signs at endpoints');
            end
            
            [obj.root, obj.iterations, obj.history] = obj.recursiveBisection(...
                obj.lowerBound, obj.upperBound, 1, []);
            
            obj.functionValue = obj.problemFunction(obj.root);
            obj.computationTime = toc;
            
            result = struct('root', obj.root, 'iterations', obj.iterations, ...
                          'time', obj.computationTime, 'converged', obj.hasConverged);
        end
        
        function [root, iter, history] = recursiveBisection(obj, a, b, currentIter, history)
            % Recursive Bisection implementation
            if currentIter > obj.maxIterations
                root = (a + b) / 2;
                iter = currentIter - 1;
                return;
            end
            
            c = (a + b) / 2;
            fc = obj.problemFunction(c);
            history(currentIter) = c;
            error_val = abs(fc);
            obj.recordHistory(c, error_val);
            
            fprintf('  Iteration %d: a=%.6f, b=%.6f, c=%.8f, f(c)=%.2e\n', ...
                    currentIter, a, b, c, fc);
            
            if obj.checkConvergence(error_val, currentIter) || (b - a)/2 < obj.tolerance
                root = c;
                iter = currentIter;
                obj.hasConverged = true;
            else
                if obj.problemFunction(a) * fc < 0
                    [root, iter, history] = obj.recursiveBisection(a, c, currentIter + 1, history);
                else
                    [root, iter, history] = obj.recursiveBisection(c, b, currentIter + 1, history);
                end
            end
        end
    end
end