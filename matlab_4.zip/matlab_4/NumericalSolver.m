classdef (Abstract) NumericalSolver < handle
    % NUMERICALSOLVER Abstract base class for all numerical solvers
    % Implements common functionality and defines abstract interface
    
    properties
        name
        tolerance
        maxIterations
        iterations
        computationTime
        hasConverged
        history
        errorHistory
        problemFunction
    end
    
    properties (Abstract, Constant)
        SOLVER_TYPE
    end
    
    methods
        function obj = NumericalSolver(name, tolerance, maxIterations)
            % Constructor
            if nargin > 0
                obj.name = name;
                obj.tolerance = tolerance;
                obj.maxIterations = maxIterations;
                obj.hasConverged = false;
                obj.history = [];
                obj.errorHistory = [];
            end
        end
        
        function recordHistory(obj, value, error)
            % Record iteration history
            obj.history(end+1) = value;
            obj.errorHistory(end+1) = error;
        end
        
        function converged = checkConvergence(obj, error, iteration)
            % Check convergence criteria
            if error < obj.tolerance
                obj.hasConverged = true;
                converged = true;
                fprintf('  Convergence achieved at iteration %d\n', iteration);
            elseif iteration >= obj.maxIterations
                obj.hasConverged = false;
                converged = false;
                fprintf('  Maximum iterations reached\n');
            else
                converged = false;
            end
        end
        
        function plotConvergence(obj)
            % Plot convergence history
            if ~isempty(obj.history)
                figure;
                subplot(2,1,1);
                plot(1:length(obj.history), obj.history, 'o-', 'LineWidth', 2);
                xlabel('Iteration');
                ylabel('Solution Value');
                title([obj.name ' - Convergence History']);
                grid on;
                
                subplot(2,1,2);
                semilogy(1:length(obj.errorHistory), abs(obj.errorHistory), 's-', 'LineWidth', 2);
                xlabel('Iteration');
                ylabel('Absolute Error');
                title([obj.name ' - Error Convergence']);
                grid on;
            end
        end
        
        function displayInfo(obj)
            % Display solver information
            fprintf('\n=== %s SOLVER ===\n', upper(obj.name));
            fprintf('Type: %s\n', obj.SOLVER_TYPE);
            fprintf('Tolerance: %.2e\n', obj.tolerance);
            fprintf('Max Iterations: %d\n', obj.maxIterations);
        end
    end
    
    methods (Abstract)
        result = solve(obj)
        validateParameters(obj)
        displayResults(obj)
    end
end