classdef (Abstract) DifferentialEquationSolver < NumericalSolver
    % DIFFERENTIALEQUATIONSOLVER Abstract class for ODE solvers
    % Inherits from NumericalSolver and adds ODE-specific functionality
    
    properties (Constant)
        SOLVER_TYPE = 'Differential Equation'
    end
    
    properties
        timeVector
        solution
        analyticalSolution
        initialCondition
        stepSize
        odeFunction
        maxError
        meanError
    end
    
    methods
        function obj = DifferentialEquationSolver(name, odeFun, tSpan, h, y0, analyticalFun, tolerance, maxIterations)
            % Call parent constructor
            obj = obj@NumericalSolver(name, tolerance, maxIterations);
            
            if nargin > 0
                obj.odeFunction = odeFun;
                obj.timeVector = tSpan(1):h:tSpan(2);
                obj.stepSize = h;
                obj.initialCondition = y0;
                obj.analyticalSolution = analyticalFun;
            end
        end
        
        function validateParameters(obj)
            % Validate ODE solver parameters
            if isempty(obj.odeFunction)
                error('ODE function must be specified');
            end
            
            if obj.stepSize <= 0
                error('Step size must be positive');
            end
            
            if isempty(obj.initialCondition)
                error('Initial condition must be specified');
            end
            
            fprintf('%s parameters validated\n', obj.name);
        end
        
        function calculateErrors(obj)
            % Calculate various error metrics
            if ~isempty(obj.analyticalSolution) && ~isempty(obj.solution)
                analyticalValues = obj.analyticalSolution(obj.timeVector);
                errors = abs(obj.solution - analyticalValues);
                obj.maxError = max(errors);
                obj.meanError = mean(errors);
                obj.errorHistory = errors;
            end
        end
        
        function displayResults(obj)
            % Display ODE solver results
            fprintf('\n=== %s RESULTS ===\n', upper(obj.name));
            fprintf('Method: %s\n', obj.name);
            fprintf('Step Size: %.4f\n', obj.stepSize);
            fprintf('Time Steps: %d\n', length(obj.timeVector));
            fprintf('Computation Time: %.6f seconds\n', obj.computationTime);
            
            if ~isempty(obj.maxError)
                fprintf('Maximum Error: %.2e\n', obj.maxError);
                fprintf('Mean Error: %.2e\n', obj.meanError);
            end
            
            fprintf('Final Value: y(%.2f) = %.6f\n', obj.timeVector(end), obj.solution(end));
        end
        
        function plotComparison(obj)
            % Plot numerical vs analytical solution
            if ~isempty(obj.analyticalSolution)
                figure;
                t_fine = linspace(obj.timeVector(1), obj.timeVector(end), 1000);
                y_analytical = obj.analyticalSolution(t_fine);
                
                plot(t_fine, y_analytical, 'k-', 'LineWidth', 3, 'DisplayName', 'Analytical');
                hold on;
                plot(obj.timeVector, obj.solution, 'r--o', 'LineWidth', 2, 'MarkerSize', 4, 'DisplayName', obj.name);
                xlabel('Time');
                ylabel('Solution');
                title(['ODE Solution: ' obj.name ' vs Analytical']);
                legend('Location', 'best');
                grid on;
                
                % Plot errors
                figure;
                errors = abs(obj.solution - obj.analyticalSolution(obj.timeVector));
                plot(obj.timeVector, errors, 'b-s', 'LineWidth', 2, 'MarkerSize', 4);
                xlabel('Time');
                ylabel('Absolute Error');
                title(['Error Analysis: ' obj.name]);
                grid on;
            end
        end
    end
end