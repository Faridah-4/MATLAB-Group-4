function main_numerical_gui()
    clear; clc; close all;
    
    fprintf('=== DEBUGGING NUMERICAL METHODS GUI ===\n');
    
    % Check if all required classes exist
    classes = {'NumericalSolver', 'RootFindingSolver', 'NewtonRaphsonSolver', ...
               'BisectionSolver', 'SecantSolver', 'DifferentialEquationSolver', ...
               'RungeKutta4Solver', 'RungeKutta2Solver', 'EulerSolver', 'NumericalMethodsGUI'};
    
    fprintf('Checking class files...\n');
    for i = 1:length(classes)
        if exist(classes{i}, 'file')
            fprintf('  ✓ %s.m found\n', classes{i});
        else
            fprintf('  ✗ %s.m MISSING\n', classes{i});
        end
    end
    
    % Test if we can create a solver directly
    fprintf('\nTesting direct solver creation...\n');
    try
        f = @(x) (8/3)*pi*x - 2000./(x.^2);
        df = @(x) (8/3)*pi + 4000./(x.^3);
        solver = NewtonRaphsonSolver(f, df, 10, 1e-8, 100);
        fprintf('  ✓ NewtonRaphsonSolver created successfully\n');
    catch ME
        fprintf('  ✗ Error creating solver: %s\n', ME.message);
    end
    
    % Create GUI
    fprintf('\nCreating GUI...\n');
    try
        gui = NumericalMethodsGUI();
        fprintf('  ✓ GUI created successfully\n');
        fprintf('\n=== INSTRUCTIONS ===\n');
        fprintf('1. Select Root Finding or ODE Solving tab\n');
        fprintf('2. Enter your parameters (defaults are provided)\n');
        fprintf('3. Click the GREEN SOLVE button\n');
        fprintf('4. Check Command Window for iteration output\n');
        fprintf('5. View results in the right panel\n');
    catch ME
        fprintf('  ✗ GUI creation failed: %s\n', ME.message);
        fprintf('  Check that all class files are in the current folder\n');
    end
end