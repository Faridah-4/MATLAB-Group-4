classdef EulerSolver < DifferentialEquationSolver
    % EULERSOLVER Concrete implementation of Euler method
    
    methods
        function obj = EulerSolver(odeFun, tSpan, h, y0, analyticalFun, tolerance, maxIterations)
            obj = obj@DifferentialEquationSolver('Euler', odeFun, tSpan, h, y0, analyticalFun, tolerance, maxIterations);
        end
        
        function result = solve(obj)
            % Implement Euler method iteratively
            tic;
            obj.validateParameters();
            
            % Initialize arrays
            t_array = zeros(1, length(obj.timeVector));
            y_array = zeros(1, length(obj.timeVector));
            t_array(1) = obj.timeVector(1);
            y_array(1) = obj.initialCondition;
            
            % Solve using iterative approach
            for step = 1:length(obj.timeVector)-1
                t_current = t_array(step);
                y_current = y_array(step);
                
                % Euler calculation
                y_next = y_current + obj.stepSize * obj.odeFunction(t_current, y_current);
                
                % Store results
                t_array(step + 1) = obj.timeVector(step + 1);
                y_array(step + 1) = y_next;
                
                if mod(step, 10) == 0
                    fprintf('  Step %d: t = %.2f, y = %.6f\n', step, t_array(step + 1), y_next);
                end
            end
            
            obj.solution = y_array;
            obj.timeVector = t_array;
            obj.calculateErrors();
            obj.computationTime = toc;
            
            result = struct('time', obj.timeVector, 'solution', obj.solution, ...
                          'max_error', obj.maxError, 'time_elapsed', obj.computationTime);
        end
    end
end